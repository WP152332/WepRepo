alert("안녕하세요?");
function greeting(nation) {
  if(nation == 'k') {
    document.getElementById("result").innerHTML = "안녕하세요?";
  }
  if(nation == 'a') {
    document.getElementById("result").innerHTML = "Hello";
  }
  if(nation == 'c') {
    document.getElementById("result").innerHTML = "Ni hao";
  }
  console.log(5+6);
}
