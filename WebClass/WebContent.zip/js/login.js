function plzLogin() {
  alert('로그인을 먼저 해주세요!');
}

function goTo() {
  location.href = './home.html';
}

$(document).ready(function() {
  $('#LF').submit(function(event) {
    event.preventDefault();
    var id = $('#id').val();
    var pw = $('#password').val();
    $.post("http://httpbin.org/post", {
        id: id,
        pwd: pw
      },
      function(data) {
        var mm = $('#mymodal');
        mm.modal();
        mm.find(".modal-body").text(data.form.id + "님 로그인 되었습니다.");
      });
  }
);
  $('#SF').submit(function(event) {
    event.preventDefault();
    var num = $('#num').val();
    var name = $('#name').val();
    $.post("http://httpbin.org/post", {
        num: num,
        name: name
      },
      function(data) {
        var mm = $('#mymodal-ss');
        mm.modal();
        mm.find(".modal-body").text(data.form.name + "님 회원가입 되었습니다.");
      });
  });
});
